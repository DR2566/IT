self.addEventListener("message", (event)=>{
  checkingLoop()
})

const checkingLoop = async () => {
  while (true) {
    console.log("trackTrader")
    // init the tracking callback
    self.postMessage("trackTrader");
    // wait a certain time
    await new Promise(resolve => setTimeout(resolve, 5000));
  }
}