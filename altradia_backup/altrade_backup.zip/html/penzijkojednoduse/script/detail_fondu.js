let fund; // Globální deklarace proměnné fund


// Funkce pro vyplnění tabulky "Výnosy"
function fillReturnsTable(fund) {
    const returnsTableBody = document.getElementById("returns-table-body");
    returnsTableBody.innerHTML = ""; // Vyčištění předchozího obsahu

    for (let year = 2017; year <= 2023; year++) {
        const value = parseFloat((fund[`${year} (%)`] || "0").replace(",", ".")).toFixed(2); // Načtení výnosu a formátování
        const row = `
            <tr>
                <td>${year}</td>
                <td>${value}%</td>
            </tr>
        `;
        returnsTableBody.innerHTML += row; // Přidání řádku do tabulky
    }

    console.log("Tabulka výnosů byla naplněna.");
}

// Funkce pro vyplnění tabulky "Poplatky"
function fillFeesTable(fund) {
    document.getElementById("fees-volume").innerHTML = fund["Poplatek z objemu"] || "N/A";
    document.getElementById("fees-profit").innerHTML = fund["Poplatek ze zisku"] || "N/A";
    document.getElementById("fees-ter").innerHTML = fund["TER"] || "N/A";

    console.log("Tabulka poplatků byla naplněna.");
}



// Funkce pro výpočet kumulovaného zisku (včetně 2016 a 2024)
function calculateCumulativeGains(fundData) {
    const cumulativeGains = [100]; // Startovací hodnota pro rok 2016
    for (let year = 2017; year <= 2023; year++) {
        const previous = cumulativeGains[cumulativeGains.length - 1]; // Předchozí hodnota zisku
        const currentGrowth = parseFloat((fundData[`${year} (%)`] || "0").replace(",", ".")) / 100; // Růst pro aktuální rok
        const newValue = previous * (1 + currentGrowth); // Složené úročení
        cumulativeGains.push(newValue);
    }

    // Předpověď pro rok 2024 na základě růstu v roce 2023
    const growth2023 = parseFloat((fundData["2023 (%)"] || "0").replace(",", ".")) / 100;
    const value2024 = cumulativeGains[cumulativeGains.length - 1] * (1 + growth2023);
    cumulativeGains.push(value2024);

    return cumulativeGains; // Vrátí hodnoty včetně 2016 a 2024
}


document.addEventListener("DOMContentLoaded", () => {
    const urlParams = new URLSearchParams(window.location.search);
    const fundName = urlParams.get("fond");
    const companyName = urlParams.get("spolecnost");

    console.log("JavaScript načten a spuštěn.");
    console.log("Načtené parametry z URL:", { fundName, companyName });

    if (!fundName || !companyName) {
        console.error("Chybí parametry v URL!");
        document.body.innerHTML = "<h1>Chybí parametry v URL!</h1>";
        return;
    }

    fetch("databaze/databaze_fondu.csv")
        .then(response => response.text())
        .then(csvText => {
            console.log("CSV soubor načten.");
            const results = Papa.parse(csvText, { header: true, skipEmptyLines: true, delimiter: ";" });
            const data = results.data;

            console.log("Načtená data z CSV:", data);

            fund = data.find(row => row.Fond === fundName && row.Společnost === companyName);

            if (!fund) {
                console.error("Fond nenalezen!");
                document.body.innerHTML = `<h1>Fond nenalezen: ${fundName} - ${companyName}</h1>`;
                return;
            }

            console.log("Fond nalezen:", fund);

            // Aktualizace obsahu stránky
            document.getElementById("fund-title").textContent = `Detail fondu: ${fundName}`;
            const fundLogoElement = document.querySelector("#fund-logo");
            const logoPath = fund.logo ? `loga_spolecnosti/${fund.logo}` : "loga_spolecnosti/default_logo.png";
            fundLogoElement.src = logoPath;
            fundLogoElement.alt = `${companyName} Logo`;

            console.log("Logo načteno z:", logoPath);
            fillReturnsTable(fund); // Vyplnění tabulky výnosů
            fillFeesTable(fund);    // Vyplnění tabulky poplatků
            initializePieChart(fund);


            // Inicializace spojnicového grafu s roky 2016–2024
            const ctx = document.getElementById("price-line-chart").getContext("2d");
            const cumulativeGains = calculateCumulativeGains(fund);

            const chart = new Chart(ctx, {
                type: "line",
                data: {
                    labels: ["2017", "2018", "2019", "2020", "2021", "2022", "2023", "2024"], // Osa X
                    datasets: [
                        {
                            label: `${fundName} (${companyName})`,
                            data: cumulativeGains, // Kumulovaný zisk včetně 2016 a 2024
                            borderColor: "#004e64",
                            backgroundColor: "rgba(0, 78, 100, 0.1)",
                            tension: 0.3,
                            fill: false,
                            pointRadius: 3,
                            pointBackgroundColor: "#004e64",
                            pointHoverRadius: 6,
                            pointHoverBackgroundColor: "#d55672",
                        },
                    ],
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            display: true,
                            labels: { 
                                color: '#000', // Legend text color
                                font: { size: 16, weight: 'bold' } // Legend font size and weight
                            },
                        },
                        tooltip: {
                            callbacks: {
                                label: function (tooltipItem) {
                                    return `${tooltipItem.raw.toFixed(2)}%`;
                                },
                            },
                        },
                    },
                    scales: {
                        x: {
                            title: {
                                display: false,
                            },
                            grid: {
                                display: false,
                            },
                            ticks: { 
                                color: '#000000',
                                font: { size: 16 }
                            }
                        },
                        y: {
                            title: {
                                display: true,
                                text: "Kumulovaný zisk (%)",
                                color: "#333",
                                font: { size: 16 } 
                            },
                            grid: {
                                color: "rgba(0, 0, 0, 0.1)",
                            },
                            beginAtZero: false,
                            ticks: { 
                                color: '#000000',
                                font: { size: 16 }
                            }
                        },
                    },
                },
            });



            
            // Logika modálního okna
            const modal = document.getElementById("fund-selection-modal");
            const fundSelectionList = document.getElementById("fund-selection-list");
            const updateChartButton = document.getElementById("update-chart-button");
            const addFundsButton = document.getElementById("add-funds-button");
            const closeModalButton = document.getElementById("close-modal-button");

            console.log("Inicializace modálního okna.");

            // Zobrazení modálního okna
            addFundsButton.addEventListener("click", () => {
                console.log("Tlačítko pro přidání fondů stisknuto.");
                modal.classList.remove("hidden");
                fundSelectionList.innerHTML = "";

                console.log("Načtená data pro výběr fondů:", data);

                data.forEach(row => {
                    if (row.Fond !== fundName) {
                        const listItem = document.createElement("li");
                        const checkbox = document.createElement("input");
                        checkbox.type = "checkbox";
                        checkbox.value = row.Fond;
                        checkbox.dataset.company = row.Společnost;

                        const label = document.createElement("label");
                        label.textContent = `${row.Fond} (${row.Společnost})`;
                        label.prepend(checkbox);

                        listItem.appendChild(label);
                        fundSelectionList.appendChild(listItem);
                    }
                });

                if (fundSelectionList.innerHTML === "") {
                    console.log("Seznam fondů je prázdný.");
                    fundSelectionList.innerHTML = "<li>Žádné další fondy k zobrazení.</li>";
                } else {
                    console.log("Fondy byly úspěšně přidány do seznamu.");
                }
            });

            // Zavření modálního okna
            modal.addEventListener("click", (event) => {
                if (event.target === modal || event.target === closeModalButton) {
                    modal.classList.add("hidden");
                    console.log("Modální okno zavřeno.");
                }
            });

            // Aktualizace grafu
            updateChartButton.addEventListener("click", () => {
                const selectedFunds = Array.from(fundSelectionList.querySelectorAll("input:checked"));
            
                if (selectedFunds.length === 0) {
                    console.warn("Žádné fondy nebyly vybrány.");
                    return;
                }
            
                const colors = ["#FF5733", "#FF33A1", "#A833FF", "#FFC133", "#33FFF2", "#33FF57", "#3357FF"];
                let colorIndex = chart.data.datasets.length;
            
                selectedFunds.forEach((checkbox) => {
                    const selectedFund = data.find(
                        (row) => row.Fond === checkbox.value && row.Společnost === checkbox.dataset.company
                    );
            
                    if (!selectedFund) {
                        console.error(`Fond ${checkbox.value} nebyl nalezen.`);
                        return;
                    }
            
                    const cumulativeGains = calculateCumulativeGains(selectedFund);
            
                    chart.data.datasets.push({
                        label: `${selectedFund.Fond} (${selectedFund.Společnost})`,
                        data: cumulativeGains, // Kumulovaný zisk
                        borderColor: colors[colorIndex % colors.length],
                        backgroundColor: colors[colorIndex % colors.length] + "33",
                        tension: 0.3,
                        fill: false,
                        pointRadius: 3,
                        pointBackgroundColor: colors[colorIndex % colors.length],
                        pointHoverRadius: 6,
                        pointHoverBackgroundColor: "#d55672",
                    });
            
                    colorIndex++;
                });
            
                chart.update();
                modal.classList.add("hidden");
            });
            
            
            
            
            
        })
        .catch(error => console.error("Chyba při načítání dat:", error));
});

// Funkce pro inicializaci koláčového grafu
function initializePieChart(data) {
    const pieCtx = document.getElementById("portfolio-pie-chart")?.getContext("2d");

    if (!pieCtx) {
        console.error("Element pro koláčový graf nebyl nalezen.");
        return;
    }

    const pieData = [
        parseFloat(parseFloat(data["Hotovost"] || 0).toFixed(2)),
        parseFloat(parseFloat(data["Státní dluhopisy ČR"] || 0).toFixed(2)),
        parseFloat(parseFloat(data["Ostatní dluhopisy"] || 0).toFixed(2)),
        parseFloat(parseFloat(data["Akcie"] || 0).toFixed(2)),
        parseFloat(parseFloat(data["Ostatní"] || 0).toFixed(2)),
    ];
    

    console.log("Data pro koláčový graf:", pieData);

    const pieLabels = ["Hotovost", "Státní dluhopisy ČR", "Ostatní dluhopisy", "Akcie", "Ostatní"];

    new Chart(pieCtx, {
        type: "pie",
        data: {
            labels: pieLabels,
            datasets: [{
                label: "Rozložení portfolia",
                data: pieData,
                backgroundColor: ['#a2ad59', '#0ca4a5', '#8b8bae', '#d55672', '#faab36']
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: true,
                    position: "bottom",
                    labels: { 
                        color: '#000', // Legend text color
                        font: { size: 16, weight: 'bold' } // Legend font size and weight
                            } 
                },
            },
        }
    });

    console.log("Koláčový graf inicializován.");
}



