document.addEventListener("DOMContentLoaded", () => {
    const csvPath = "databaze/databaze_fondu.csv"; // Relativní cesta k CSV souboru
    const tableBody = document.querySelector("#funds-table tbody");
    let fundData = []; // Uložení načtených dat pro pozdější řazení
    let originalData = []; // Původní data z CSV pro obnovu původního pořadí

    // Načtení CSV pomocí PapaParse
    Papa.parse(csvPath, {
        download: true,
        header: true,
        skipEmptyLines: true,
        delimiter: ";",
        complete: function (results) {
            fundData = results.data.map((row, index) => {
                // Očištění a zpracování hodnot z CSV
                return {
                    ...row,
                    "index": index, // Uložení původního indexu pro obnovu původního pořadí
                    "TER": parseFloat((row["TER"] || "0").trim().replace(",", ".").replace("%", "")) || 0,
                    "Průměr": parseFloat((row["Průměr"] || "0").trim().replace(",", ".").replace("*", "")) || 0,
                };
            });

            originalData = [...fundData]; // Uložení původního pořadí dat

            console.log("Načtená data:", fundData); // Diagnostický výpis dat

            if (fundData.length === 0) {
                console.error("CSV neobsahuje žádná data.");
                return;
            }

            // Vykreslení tabulky při načtení
            renderTable(fundData);

            // Přidání funkcí řazení
            document.getElementById("sort-alphabetically").addEventListener("click", () => {
                const sortedData = sortOriginalOrder(originalData); // Použití funkce pro obnovení pořadí
                renderTable(sortedData);
            });

            // Funkce pro obnovení původního pořadí
            function sortOriginalOrder(data) {
                return data.sort((a, b) => a.index - b.index);
            }


            document.getElementById("sort-fee").addEventListener("click", () => {
                const sortedData = [...fundData].sort((a, b) => {
                    if (a.TER === b.TER) {
                        return b["Průměr"] - a["Průměr"]; // Sekundární kritérium: Výnosy
                    }
                    return a.TER - b.TER; // Primární kritérium: TER
                });
                renderTable(sortedData);
            });

            document.getElementById("sort-performance").addEventListener("click", () => {
                const sortedData = [...fundData].sort((a, b) => b["Průměr"] - a["Průměr"]); // Sestupné řazení podle výnosů
                renderTable(sortedData);
            });
        },
        error: function (error) {
            console.error("Chyba při načítání CSV:", error);
        }
    });

    // Funkce pro vykreslení tabulky
    function renderTable(data) {
        tableBody.innerHTML = ""; // Vymaže obsah tabulky

        data.forEach(row => {
            const logoPath = `loga_spolecnosti/${row.logo || "default_logo.png"}`;
            const fundName = row.Fond || "N/A";
            const companyName = row.Společnost || "N/A";
            const fee = row.TER;
            const performance = row["Průměr"];
            const detailUrl = `detail_fondu.html?fond=${encodeURIComponent(fundName)}&spolecnost=${encodeURIComponent(companyName)}`;

            // Kontrola, zda existují data od roku 2017
            let missingData = false;
            for (let year = 2017; year <= 2023; year++) {
                if (!row[`${year} (%)`]) {
                    missingData = true;
                    break;
                }
            }

            const tableRow = document.createElement("tr");
            tableRow.innerHTML = `
                <td>
                    <img class="logo-img" src="${logoPath}" alt="${companyName} Logo" 
                         onerror="this.onerror=null; this.src='loga_spolecnosti/default_logo.png';">
                </td>
                <td>${fundName}</td>
                <td>${fee.toFixed(2)}%</td>
                <td>${performance.toFixed(2)}${missingData ? "*" : ""}%</td> <!-- Přidání hvězdičky -->
                <td>
                    <button class="details-button" onclick="window.location.href='${detailUrl}'">
                        Detaily fondu
                    </button>
                </td>
            `;

            tableBody.appendChild(tableRow);
        });

        // Přidání poznámky pod tabulku
        const note = document.getElementById("note");
        if (!note) {
            const tableContainer = document.querySelector(".info-box");
            const noteElement = document.createElement("p");
            noteElement.id = "note";
            noteElement.style.marginTop = "10px";
            noteElement.style.fontStyle = "italic";
            noteElement.style.color = "#555";
            noteElement.innerText = "Poznámka: * Zhodnocení označené hvězdičkou znamená, že fond vznikl až po roce 2017, což může vytvářet zkreslení při srovnání.";
            tableContainer.appendChild(noteElement);
        }
    }
});



// Konstanty a proměnné
let savingsChart;
const retirementAge = 65; // Nastavený důchodový věk

document.getElementById('calculate').addEventListener('click', () => {
    const fund = document.getElementById('fund').value;
    const contribution = parseFloat(document.getElementById('contribution').value);
    const employer = parseFloat(document.getElementById('employer').value || 0);
    const age = parseInt(document.getElementById('age').value);
    const yearsToRetirement = retirementAge - age;

    const funds = {
        'fund1': { return: 0.0561 },
        'fund2': { return: 0.0335 },
        'fund3': { return: 0.0095 },
        'fund4': { return: 0.0113 },
    };

    const stateSupport = {
        minContribution: 500, // Minimální měsíční úložka pro získání státní podpory
        maxContribution: 1700, // Maximální měsíční úložka, z které se počítá státní podpora
        supportPercent: 0.2 // Procentuální výše státní podpory
    };

    let cumulativeContributions = 0;
    let cumulativeEmployerContributions = 0;
    let cumulativeStateSupportContributions = 0;
    let cumulativeProfits = 0;

    let contributions = [];
    let employerContributions = [];
    let stateSupportContributions = [];
    let profits = [];
    let totalSavings = [];

    for (let i = 0; i < yearsToRetirement; i++) {
        let annualContribution = contribution * 12;
        let employerContribution = employer * 12;

        // Výpočet státní podpory pouze pokud měsíční příspěvek splňuje podmínky
        let stateContribution = 0;
        if (contribution >= stateSupport.minContribution) {
            stateContribution = Math.min(contribution, stateSupport.maxContribution) * stateSupport.supportPercent * 12;
        }
        

        let annualTotal = annualContribution + employerContribution + stateContribution;
        let profit = (cumulativeContributions + cumulativeEmployerContributions + cumulativeStateSupportContributions + cumulativeProfits + annualTotal) * funds[fund].return;

        cumulativeContributions += annualContribution;
        cumulativeEmployerContributions += employerContribution;
        cumulativeStateSupportContributions += stateContribution;
        cumulativeProfits += profit;

        contributions.push(cumulativeContributions);
        employerContributions.push(cumulativeEmployerContributions);
        stateSupportContributions.push(cumulativeStateSupportContributions);
        profits.push(cumulativeProfits);
        totalSavings.push(cumulativeContributions + cumulativeEmployerContributions + cumulativeStateSupportContributions + cumulativeProfits);
    }

    document.getElementById('results').innerHTML = `
    <p>Celková naspořená částka za ${yearsToRetirement} let: <strong>${formatNumber(totalSavings[totalSavings.length - 1].toFixed(0))} Kč</strong></p>
    <p>Celkové příspěvky účastníka: <strong>${formatNumber(cumulativeContributions.toFixed(0))} Kč</strong></p>
    <p>Celkové příspěvky zaměstnavatele: <strong>${formatNumber(cumulativeEmployerContributions.toFixed(0))} Kč</strong></p>
    <p>Celková státní podpora: <strong>${formatNumber(cumulativeStateSupportContributions.toFixed(0))} Kč</strong></p>
`;


    const ctx = document.getElementById('savingsChart').getContext('2d');
    if (savingsChart) {
        savingsChart.destroy();
    }
    savingsChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: Array.from({ length: yearsToRetirement }, (_, i) => `Rok ${i + 1}`),
            datasets: [
                {
                    label: 'Úložky účastníka',
                    data: contributions,
                    backgroundColor: '#6a0dad',
                },
                {
                    label: 'Příspěvky zaměstnavatele',
                    data: employerContributions,
                    backgroundColor: '#0073e6',
                },
                {
                    label: 'Státní podpora',
                    data: stateSupportContributions,
                    backgroundColor: '#00b050',
                },
                {
                    label: 'Zhodnocení',
                    data: profits,
                    backgroundColor: '#ffa500',
                },
            ]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { 
                    position: 'top', 
                    labels: { 
                        color: '#000', // Legend text color
                        font: { size: 16, weight: 'bold' } // Legend font size and weight
                    } 
                },
                tooltip: {
                    callbacks: {
                        label: function (tooltipItem) {
                            let num = tooltipItem.raw.toFixed(0); // Convert to integer-like string
                            let numString = Number(num).toLocaleString('fr-FR'); // Convert to number and format
                            return `${tooltipItem.dataset.label}: ${numString} Kč`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    stacked: true,
                    ticks: { 
                        color: '#000000',
                        font: { size: 16 }
                    }
                },
                y: {
                    stacked: true, 
                    title: { 
                        display: true, 
                        text: 'Kumulativní zůstatek (Kč)',
                        color: '#000000',
                        font: { size: 16 } 
                    },
                    ticks: { 
                        color: '#000000',
                        font: { size: 16 }
                    }
                }
            }
        }
    });
});



function formatNumber(number) {
    return Number(number).toLocaleString('cs-CZ', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
}


function calculateMonthlySavings(goal, currentSavings, years, rate) {
    const monthlyRate = rate / 12 / 100;
    const months = years * 12;
    const futureValue = goal - currentSavings * Math.pow(1 + monthlyRate, months);
    if (futureValue <= 0) return 0;
    return futureValue * monthlyRate / (Math.pow(1 + monthlyRate, months) - 1);
}

function calculatePension() {
    const income = parseFloat(document.getElementById('income').value);
    const netIncome = parseFloat(document.getElementById('netIncome').value);
    const age = parseInt(document.getElementById('age').value);
    const startWorkAge = parseInt(document.getElementById('startWorkAge').value);
    const gender = document.getElementById('gender').value;
    const children = parseInt(document.getElementById('children').value);
    const currentSavings = parseFloat(document.getElementById('currentSavings').value);

    const averageWage = 46600; // Průměrná mzda v Kč
    const basicPension = 4660; // Základní výměra pro rok 2025 v Kč
    const retirementAge = 65;
    const yearsWorked = Math.max(0, retirementAge - startWorkAge);

    // Redukce hrubého příjmu
    let reducedIncome = 0;
    const firstThreshold = 0.44 * averageWage;
    const secondThreshold = 4 * averageWage;

    if (income <= firstThreshold) {
        reducedIncome = income;
    } else if (income <= secondThreshold) {
        reducedIncome = firstThreshold + (income - firstThreshold) * 0.26;
    } else {
        reducedIncome = firstThreshold + (secondThreshold - firstThreshold) * 0.26;
    }

    // Výpočet procentní výměry
    const percentagePension = (yearsWorked * 1.5 / 100) * reducedIncome;

    // Bonus za děti
    const childBonus = children * 500;

    // Celkový důchod
    const totalPension = Math.floor(basicPension + percentagePension + childBonus);

    // Výpočet očekávané doby pobírání důchodu
    const lifeExpectancy = gender === 'male' ? 19.5 : 28.5;
    const expectedYearsInPension = lifeExpectancy;

    // Propad příjmů
    const incomeDrop = Math.floor(netIncome - totalPension);

    // Výpočet procenta bývalých příjmů
    const percentOfIncome = (totalPension / netIncome) * 100;

    // Výpočet měsíčního spoření pro každou úroveň příjmů a fondy
    const yearsUntilRetirement = retirementAge - age;
    const fundRates = {
        dynamicky: 5.61,
        vyvazeny: 3.35,
        konzervativni: 0.95,
        transformovany: 1.13
    };
    const detailedSavings = [50, 60, 70, 80, 90, 100].map(level => {
        const targetIncome = (level / 100) * netIncome;
        const deficit = targetIncome - totalPension;

        const rows = Object.entries(fundRates).map(([fund, rate]) => {
            const monthly = calculateMonthlySavings(
                12 * expectedYearsInPension * deficit,
                currentSavings,
                yearsUntilRetirement,
                rate
            );
            // Pokud není nutné spořit, zobrazí se "0 Kč"
            return `<td>${monthly > 0 ? formatNumber(Math.floor(monthly)) + " Kč" : "0 Kč"}</td>`;
        }).join('');

        return `
            <tr>
                <td>${level}%</td>
                ${rows}
            </tr>`;
    }).join('');



    // Zobrazení výsledků
    const resultsDiv = document.getElementById('results');
    resultsDiv.innerHTML = `
        <h2>Odhadovaný důchod</h2>
        <table class="aligned-table">
            <tbody>
                <tr>
                    <th>Měsíční výše důchodu</th>
                    <td><strong>${formatNumber(totalPension)} Kč</strong></td>
                </tr>
                <tr>
                    <th>Důchod jako % bývalých čistých příjmů</th>
                    <td><strong>${percentOfIncome.toFixed(2)}%</strong></td>
                </tr>
                <tr>
                    <th>Očekávaná doba pobírání důchodu</th>
                    <td><strong>${expectedYearsInPension.toFixed(1)} let</strong></td>
                </tr>
                <tr>
                    <th>Propad příjmů při přechodu do důchodu</th>
                    <td><strong>${formatNumber(incomeDrop)} Kč</strong></td>
                </tr>
            </tbody>
        </table>
    
        <h3>Měsíční spoření podle fondů pro různé úrovně příjmů</h3>
        <table class="aligned-table">
            <thead>
                <tr>
                    <th>Cíl (% bývalých příjmů)</th>
                    <th>Dynamický fond</th>
                    <th>Vyvážený fond</th>
                    <th>Konzervativní fond</th>
                    <th>Transformovaný fond</th>
                </tr>
            </thead>
            <tbody>
                ${detailedSavings}
            </tbody>
        </table>
    `;
}



function showDetails(id) {
    document.getElementById(id).scrollIntoView({ behavior: 'smooth' });
}



