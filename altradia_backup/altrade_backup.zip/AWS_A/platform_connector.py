import requests

class PLATFORM:   
    def __init__(self, platform_url):
        self.url = platform_url
    
    def get_symbol_info(self, symbol_name):
        response = requests.get(self.url+"get-symbol-info?symbolName="+symbol_name, verify=False).json()
        return response['symbol']
    
    def get_symbol_prices(self, symbol_name):
        response = requests.get(self.url+"get-symbol-prices?symbolName="+symbol_name, verify=False).json()
        return response['ask'], response['bid']
    
    def get_symbol_names(self):
        response = requests.get(self.url+"get-symbol-names", verify=False).json()
        return response['symbol_name_list']
    

platform_api = PLATFORM("https://192.168.0.74:7778/")

# res = platform_api.get_symbol_info("EURUSD")
# print(res)