from log import log
import math
from platform_connector import platform_api


class BASIC:
    def __init__(self, counter_instance):
        self.counter_instance = counter_instance
        
    def count_volume(self, position_obj, current_entry_price, remaining_loss, free_margin):
        return position_obj['Volume'] / position_obj['ContractSize']
        
    
class STANDARD:
    def __init__(self, counter_instance):
        self.counter_instance = counter_instance
    
    def count_volume(self, position_obj, current_entry_price, remaining_loss, free_margin):        
        symbol_name = position_obj["SymbolName"]
        balance_on_entry = position_obj['BalanceOnEntry']
        stop_loss = position_obj['StopLoss']
        contract_size = position_obj['ContractSize']
        
        convertion_ratio = self.counter_instance.convertion_ratio
        if convertion_ratio == 0: # the error about convertion ratio is already printed the that method
            return 0
        
        # count the margin by the ALTRADIA MNMNGMNT 2.0
        fee_per_unit = self.counter_instance.fee_per_lot / contract_size
        margin = (remaining_loss*balance_on_entry*current_entry_price) / (self.counter_instance.leverage * (abs(current_entry_price - stop_loss) + fee_per_unit * convertion_ratio * current_entry_price))
        # check if we are able to allocate margin
        margin = 0.9*free_margin if(margin >= 0.9*free_margin) else margin 
        units = margin * self.counter_instance.leverage * convertion_ratio
        
        volume = units / contract_size
        volume = math.floor(volume*100) / 100 # floor the two decimal numbers of volume
        
        if volume > 100 or volume < 0.01: # we will assume that min LOT size is 0.01 and maximum LOT size is 100
            log.print("Volume is not inside the interval")
            log.print("Volume: "+str(volume))
            log.print(current_entry_price)
            log.print(remaining_loss)
            return 0
        
        if not self.check_risk(volume, contract_size, current_entry_price, stop_loss, convertion_ratio, balance_on_entry, remaining_loss): # check if there is no bug in counting
            log.print("too high risk, skiping the trade...")
            log.print(position_obj)
            log.print([volume, contract_size, current_entry_price, stop_loss, convertion_ratio, balance_on_entry])
            log.print("volume: "+str(volume))
            return 0
        
        return volume
    
    def check_risk(self, volume, contract_size, current_entry_price, stop_loss, convertion_ratio, balance_on_entry, remaining_loss):
        units = volume * contract_size 
        margin = units / self.counter_instance.leverage / convertion_ratio
        fee_per_unit = self.counter_instance.fee_per_lot / contract_size
        fee_loss = units * fee_per_unit
        capital_loss = margin * self.counter_instance.leverage * (abs(current_entry_price - stop_loss) / current_entry_price) 
        total_possible_loss = balance_on_entry * remaining_loss
        return (fee_loss + capital_loss) <= total_possible_loss

class COUNTER:
    def __init__(self):
        self.max_loss_per_trade = 0.03 # 3 percent
        self.fee_per_lot = 4.5 # USD per LOT per round
        self.account_currency = "USD"
        self.leverage = 500
        self.basic = BASIC(self)
        self.standard = STANDARD(self)
        self.model_dict = {
            "basic": self.basic,
            "standard": self.standard
        }
        self.convertion_ratio = None
        
        
    def update_convertion_ratio(self, symbol_name, current_price): # gets any of symbols and its current price and returns a convertion ratio
        quote_currency = platform_api.get_symbol_info(symbol_name)['currency_profit']
        # check if the pair includes the account currency
        if quote_currency == self.account_currency: # the account currency is the quote currency
            convertion_ratio = 1 / current_price
        elif symbol_name.find(self.account_currency) == 0: # the account currency is the base currency in pair only for FOREX
            convertion_ratio = 1
        # elif the pair does not include the account currency
        elif symbol_name.find(self.account_currency) == -1:
            needed_currency = quote_currency
            # get convertion_pair
            symbol_name_list = [s['name'] for s in platform_api.get_symbol_names() if needed_currency in s['name'] and self.account_currency in s['name']]
            if len(symbol_name_list) != 0:
                convertion_symbol = symbol_name_list[0]
            else:
                log.print("convertion_symbol not found")
                return 0
            # log.print("Convertion symbol: "+convertion_symbol)
            # get ask and bid of the convertion symbol
            ask, bid = platform_api.get_symbol_prices(convertion_symbol)
            # decide the order of the account currency in the convertion symbol
            if convertion_symbol.find(self.account_currency) == 0: # if the account currency is in the convertion pair as the base currency (= 3.b)
                convertion_ratio = bid * 1/current_price
            elif convertion_symbol.find(self.account_currency) == 3: # if the account currency is in the convertion pair as the quote currency (= 3.a)
                convertion_ratio = 1/ask * 1/current_price
            else:
                log.print("something went wrong when counting the convertion ratio")
                return 0
            
            # log.print("convertion_price ask: "+str(ask))
            # log.print("convertion_price bid: "+str(bid))
            
        # log.print("convertion_ratio: "+str(convertion_ratio))
        self.convertion_ratio = convertion_ratio
        return 1
    
    def count_margin(self, position_obj, volume):
        contract_size = position_obj['ContractSize']
        units = volume * contract_size
        margin = units / (self.leverage * self.convertion_ratio)
        return margin 
    
    
counter = COUNTER()