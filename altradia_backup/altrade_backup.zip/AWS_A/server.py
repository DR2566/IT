from aiohttp import web
import asyncio
import aiohttp_cors
from log import log
import ssl  # Import the SSL module
import requests
from AUTHENTIFICATOR import auth
from WS_SERVER import ws_server, start_websocket_server

from trade_executor import trade_executor
from database import User, Plan, Position, Entry, Close


import warnings
import urllib3

# Suppress only the specific warning from urllib3
warnings.filterwarnings("ignore", category=urllib3.exceptions.InsecureRequestWarning)

# Add paths to your SSL certificate and private key
SSL_CERTIFICATE = '/etc/letsencrypt/live/algapia.zapto.org/cert.pem'
SSL_KEY = '/etc/letsencrypt/live/algapia.zapto.org/privkey.pem'

new_trade_id_list = []

# ------------------------------------------------      REST API server           -----------------------------------------------------

routes = web.RouteTableDef()
AWS_S_address = 'https://192.168.0.74:7778/'

def send_to_AWS_S(method, path, data=None):
    if method == 'POST':
        resp = requests.post(AWS_S_address + path, json=data, verify=False)
        return resp.json(), resp.status_code
    elif method == 'GET':
        resp = requests.get(AWS_S_address + path, verify=False)
        return resp.json(), resp.status_code

@routes.post('/new-trade')
async def new_trade(request):
    global new_trade_id_list
    
    try:
        # get data from APC
        data = await request.json()
        position_obj = data
        
        deviceUID = request.headers.get('Authorization')[7:]
        cTraderId = auth.deschiffre_cTraderId(deviceUID)
        
        # check deviceUID of the client
        res_auth = auth.is_registered(cTraderId, deviceUID)
        if not res_auth == 1: 
            response = {"Result":res_auth}
            return web.json_response(response, status=200)
        
        new_trade_id_list.append(position_obj["TradeId"])
        # send this new trade object to AWC
        result = await ws_server.send_new_trade(deviceUID, position_obj)
        
        # send the response to the APC
        result = {
            "Result":"new-trade registered"
        }
        return web.json_response(result, status=200)
    except Exception as e:
        # send the response to the APC
        result = {
            "Result":str(e)
        }
        return web.json_response(result, status=200)

@routes.post('/enter-trade')
async def enter_trade(request):
    global new_trade_id_list
    
    try:
        data = await request.json()
        new_trade_obj = data.get("newTradeObj")
        trade_id = new_trade_obj['TradeId']
        
        deviceUID = request.headers.get('Authorization')[7:]
        cTraderId = auth.deschiffre_cTraderId(deviceUID)
        
        # check deviceUID of the client
        res_auth = auth.is_registered(cTraderId, deviceUID)
        if not res_auth == 1: 
            response = {"Result":res_auth}
            return web.json_response(response, status=200)
        
        # copy trade on AWS_S
        # response_data, status = send_to_AWS_S('POST', 'enter-trade', new_trade_obj)
        new_trade_id_list.remove(trade_id)
        
        # simulate trade opening
        trade_executor.enter_trade(new_trade_obj, cTraderId)
        
        result = {
            "Result":"entered"
        }
        
        return web.json_response(result, status=200)
    
    except Exception as e:
        result = {
            "Result": str(e)
        }
        
        return web.json_response(result, status=200)

@routes.post('/modify-position')
async def modify_position(request):
    global new_trade_id_list
    
    try:
        # get data from APC
        data = await request.json()
        position_obj = data
        
        deviceUID = request.headers.get('Authorization')[7:]
        cTraderId = auth.deschiffre_cTraderId(deviceUID)
        
        # check deviceUID of the client
        res_auth = auth.is_registered(cTraderId, deviceUID)
        if not res_auth == 1: 
            response = {"Result":res_auth}
            return web.json_response(response, status=200)
        
        # if not position_obj['TradeId'] in new_trade_id_list:
            # send to modify the opened trade 
            # response_data, status = send_to_AWS_S('POST', 'modify-position', position_obj)
        # elif position_obj['TradeId'] in new_trade_id_list:
        #     # if the position is the newTradeObj, then send the AWC to update the stored object
        #     response_data = await ws_server.send_new_trade(deviceUID, position_obj)
        #     status = 200
            
        result = {
            "Result":"modified"
        }
        
        return web.json_response(result, status=200)
    except Exception as e:
        result = {
            "Result":str(e)
        }
        
        return web.json_response(result, status=200)

@routes.get('/close-position')
async def close_position(request):
    
    try:
    
        deviceUID = request.headers.get('Authorization')[7:]
        cTraderId = auth.deschiffre_cTraderId(deviceUID)
        
        # check deviceUID of the client
        res_auth = auth.is_registered(cTraderId, deviceUID)
        if not res_auth == 1: 
            response = {"Result":res_auth}
            return web.json_response(response, status=200)
        
        position_id = int(request.query.get('positionId'))
        # two prices because in cTrader we do not know wich direction is the position
        ask = float(request.query.get('ask').replace(",", "."))
        bid = float(request.query.get('bid').replace(",", "."))
        stop_loss = float(request.query.get('stopLoss').replace(",", "."))
        take_profit = float(request.query.get('takeProfit').replace(",", "."))
        
        # close the subposition on AWS_S
        # response_data, status = send_to_AWS_S('GET', f'close-position?positionId={position_id}')
        
        # simulate closing trade on AWS_C
        trade_executor.close_position(position_id, ask, bid, stop_loss, take_profit)
        
        result = {
            "Result":"modified"
        }
        
        return web.json_response(result, status=200)
    
    except Exception as e:
        result = {
            "Result": str(e)
        }
        
        return web.json_response(result, status=200)

@routes.get('/apc-login')
async def login(request):
    try:
        deviceUID = request.headers.get('Authorization')[7:]
        cTraderId = auth.deschiffre_cTraderId(deviceUID)
        
        # check deviceUID of the client
        res_auth = auth.is_registered(cTraderId, deviceUID) # if !cTraderId || !deviceUID
        if not res_auth == 1: 
            response = {"Result":res_auth}
            return web.json_response(response, status=200)
        
        result = {
            "Result": "logged in"
        }
        
        return web.json_response(result, status=200)
    
    except Exception as e:
        result = {
            "Result": str(e)
        }
        
        return web.json_response(result, status=200)
    
    
@routes.post('/register-device')
async def register_deviceUID(request):
    try:
        # get data
        data = await request.json()
        deviceUID = data.get('deviceUID')
        cTraderId = auth.deschiffre_cTraderId(deviceUID)
        googleToken = data.get('googleToken')
        
        # verify token
        verified_user_dict = auth.verify_googleToken(googleToken)
        if verified_user_dict is None:
            result = {
                "Result": "verification error"
            }
            return web.json_response(result, status=200)
            
        googleId = verified_user_dict["googleId"]
        
        auth.register_user(verified_user_dict) # just for beta version, then redirect to main web ALTRADIA page
        auth_res = auth.register_device(deviceUID, googleId, cTraderId)
        
        if auth_res != 1:
            response = {"Result":auth_res}
            return web.json_response(response, status=200)
        
        result = {
            "Result": "New device registered :-)"
        }
        return web.json_response(result, status=200)
    
    except Exception as e:
        result = {
            "Result":str(e)
        }
        return web.json_response(result, status=200)
    
    
@routes.get('/ping')
async def ping(request):
    return web.json_response({"response":"ping"})


# ------------------------------        restapi for ALTRADIA WEB     -----------------------------------------------------------------
    
@routes.get('/get-user-info')
async def get_user_info(request):
    
    try:
        # get data
        googleToken = request.headers.get('Authorization')[7:]
        
        # verify token
        verified_user_dict = auth.verify_googleToken(googleToken)
        if verified_user_dict is None:
            response = {
                "status": 0,
                "error": "verification error"
            }
            return web.json_response(response, status=200)
        
        googleId = verified_user_dict['googleId']
        user = User.get(googleId=googleId)
        if not user:
            response = {
                "status": 0,
                "error": "user does not exist"
            }
            return web.json_response(response, status=200)
        
        name = user.name
        email = user.email
        
        response = {
            "status":1,
            "data":{
                "name":name,
                "email":email
            }
        }
        
        return web.json_response(response, status=200)
    
    except Exception as e:
        response = {
            "status": 0,
            "error": str(e)
        }
        
        return web.json_response(response, status=200)
    
@routes.get('/authorize-user')
async def authorize_user(request):
    try:
        # get data
        googleToken = request.headers.get('Authorization')[7:]
        
        # verify token
        verified_user_dict = auth.verify_googleToken(googleToken)
        if verified_user_dict is None:
            response = {
                "status": 0,
                "error": "verification error"
            }
            return web.json_response(response, status=200)
        
        # if not registered, then register the user
        auth.register_user(verified_user_dict)
        
        response = {
            "status": 1,
            "result": "Authorized successfully :-)"
        }
        
        return web.json_response(response, status=200)
    
    except Exception as e:
        response = {
            "status": 0,
            "result": str(e)
        }
        return web.json_response(response, status=200)
    
@routes.get('/get-positions')
async def get_positions(request):
    try:
        # get data
        googleToken = request.headers.get('Authorization')[7:]
        
        # verify token
        verified_user_dict = auth.verify_googleToken(googleToken)
        if verified_user_dict is None:
            response = {
                "status": 0,
                "error": "verification error"
            }
            return web.json_response(response, status=200)
        
        plan_id_basic = Plan.get(name="basic").id
        plan_id_standard = Plan.get(name="standard").id
        
        google_id = verified_user_dict['googleId']
        # user_id = User.get(googleId=google_id).id
        user_id = 22 # tatka id
        
        basic_plan_positions = Position.get(UserId=user_id, PlanId=plan_id_basic, dictionary_repre = True, not_null_attributes_list=['percChange'])
        standard_plan_positions = Position.get(UserId=user_id, PlanId=plan_id_standard, dictionary_repre = True, not_null_attributes_list=['percChange'])
        
        response = {
            "status": 1,
            "data": {
                "plan": {
                    "basic": basic_plan_positions,
                    "standard": standard_plan_positions,
                }
            }
        }
        
        return web.json_response(response, status=200)
    
    except Exception as e:
        response = {
            "status": 0,
            "error": str(e)
        }
        return web.json_response(response, status=200)
    
app = web.Application()

# Setup CORS
cors = aiohttp_cors.setup(app, defaults={
    "*": aiohttp_cors.ResourceOptions(
        allow_credentials=True,
        expose_headers="*",
        allow_headers="*",
    )
})

# Add routes to the application
app.add_routes(routes)

# Add CORS to each route
for route in list(app.router.routes()):
    cors.add(route)

async def start_http_server():
    ssl_context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
    ssl_context.load_cert_chain(certfile=SSL_CERTIFICATE, keyfile=SSL_KEY)

    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "0.0.0.0", 7778, ssl_context=ssl_context)
    await site.start()
    log.print("HTTP server started with SSL (HTTPS)")

async def main():
    log.clear()
    await asyncio.gather(start_http_server(), start_websocket_server())

if __name__ == '__main__':
    asyncio.run(main())
