import os
from datetime import datetime

class LOG:
    def __init__(self):
        self.log_path = self.get_log_path()
        
    def get_log_path(self):
        file_name_list = os.listdir("./")
        log_name_list = [name for name in file_name_list if ".log" in name]
        # log_name_list = []
        
        return f"./output_{len(log_name_list)}.log"
                
        
    def print(self, output):
        log_file = open(self.log_path, "a")
        print(output)
        output = str(output)+"\n"
        log_file.write(output)
        log_file.close()
        
    def clear(self):
        log_file = open(self.log_path, "w")
        output = ""
        log_file.write(output)
        log_file.close()
        
    def server_format_log(self, service_name, header, message, enter=True):
        self.print(f"-{service_name}--------: {header} -----------------------------------{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        self.print(message)
        if enter: self.print("\n")
        
log = LOG()