import mysql.connector
import json
from datetime import datetime
import time
from log import log

class DATABASE:
    def __init__(self, host="localhost", user="altradia_client", password="XHVm)c8yi@qk_61)", database_name="ALTRADIA"):
        self.host = host
        self.user = user
        self.password = password
        self.database_name = database_name

    # -----------------------------   CONNECTION   -----------------------------------
    def get_connection(self):
        retries = 3  # Retry connecting 3 times
        while retries:
            try:
                # Create a new connection each time
                connection = mysql.connector.connect(
                    host=self.host,
                    user=self.user,
                    password=self.password,
                    database=self.database_name
                )
                return connection
            except mysql.connector.Error as err:
                retries -= 1
                time.sleep(1)  # Wait before retrying
        raise Exception("Failed to establish a database connection after multiple attempts.")
    
    
    def execute_query(self, query, params=None, dictionary_bool=False):
        try:
            connection = self.get_connection()
            cursor = connection.cursor(dictionary=dictionary_bool)
            
            if params:
                cursor.execute(query, params)
            else:
                cursor.execute(query)
            
            # Commit the changes for non-SELECT queries
            if query.strip().lower().startswith('select'):
                response = cursor.fetchall()
            elif query.strip().lower().startswith('update'):
                connection.commit()
                response = cursor.rowcount  # Number of affected rows
            else:
                connection.commit()
                response = cursor.lastrowid  # Number of affected rows
            
            cursor.close()
            connection.close()
            return 1, response
        
        except mysql.connector.Error as err:
            log.print(err)
            return 0, err
        
        except Exception as e:
            log.print(e)
            return 0, e
    
class BaseModel:
    
    @classmethod
    def create(cls, **kwargs):
        # Dynamically generate SQL for creating a new entry
        columns = ', '.join(kwargs.keys())
        values = ', '.join(['%s'] * len(kwargs))
        sql = f"INSERT INTO `{cls.table_name}`({columns}) VALUES({values});"
        params = tuple(kwargs.values())
        
        status, res = database.execute_query(sql, params)
        if status == 0:
            return res
        id = res  # Assuming the response contains the inserted ID

        # Instantiate and return a new object
        return cls(id, **kwargs)

    @classmethod
    def get(cls, dictionary_repre=False, not_null_attributes_list=False, **kwargs):
        # Dynamically generate SQL for fetching an entry based on multiple attributes
        conditions = ' AND '.join([f"{key} = %s" for key in kwargs.keys()])
        params = tuple(kwargs.values())
        
        if not_null_attributes_list:
            null_filters = ' AND '.join([f"{key} IS NOT NULL" for key in not_null_attributes_list])
            conditions = f"{conditions} AND {null_filters}"
        
        sql = f"SELECT * FROM `{cls.table_name}` WHERE {conditions};"
        
        status, res = database.execute_query(sql, params, dictionary_bool=True)
        if status == 0:
            print(res)
            return
        
        if len(res) > 1:
            obj_list = [cls(**obj_dict) for obj_dict in res]
            if dictionary_repre:
                obj_list = list(map(lambda x: x.dictionary(), obj_list))
            return obj_list
        elif len(res) == 1:
            obj_dict = res[0]
            return cls(**obj_dict)
        else:
            return None

    @classmethod
    def get_all(cls):
        # Dynamically generate SQL for fetching all entries
        sql = f"SELECT * FROM `{cls.table_name}`;"
        
        status, res = database.execute_query(sql, dictionary_bool=True)
        if status == 0:
            print(res)
            return
        
        # Return a list of instantiated objects
        obj_list = [cls(**obj_dict) for obj_dict in res]
        return obj_list

    def save(self):
        # Dynamically generate SQL for updating an existing entry
        attributes = vars(self)
        columns = ', '.join([f"{key} = %s" for key in attributes if key != 'id'])
        params = tuple(getattr(self, key) for key in attributes if key != 'id') + (self.id,)
        
        sql = f"UPDATE `{self.table_name}` SET {columns} WHERE id = %s;"
        
        status, res = database.execute_query(sql, params)
        return res
    
    def __repr__(self):
        return str(vars(self))
    
    def dictionary(self):
        return vars(self)
    
    
class Entry(BaseModel):
    table_name = 'Entry'

    def __init__(self, id, entryPrice, stopLoss, takeProfit, balance, PositionId):
        self.id = id
        self.entryPrice = entryPrice
        self.stopLoss = stopLoss
        self.takeProfit = takeProfit
        self.balance = balance
        self.PositionId = PositionId
    
class Close(BaseModel):
    table_name = 'Close'
    
    def __init__(self, id, closePrice, stopLoss, takeProfit, balance, PositionId):
        self.id = id
        self.closePrice = closePrice
        self.stopLoss = stopLoss
        self.takeProfit = takeProfit
        self.balance = balance
        self.PositionId = PositionId
        
class Plan(BaseModel):
    table_name = 'Plan'
    
    def __init__(self, id=None, name=None):
        self.id = id  # Assuming `id` is auto-incremented
        self.name = name

class Position(BaseModel):
    table_name = "Position"
    
    def __init__(self, id=None, timestamp=None, cPositionId=None, symbolName=None, direction=None, volume=None, margin=None, UserId=None, PlanId=None, EntryId=None, CloseId=None, percChange=None):
        self.id = id
        self.timestamp = timestamp
        self.cPositionId = cPositionId
        self.symbolName = symbolName
        self.direction = direction
        self.volume = volume
        self.margin = margin
        self.UserId = UserId
        self.PlanId = PlanId
        self.percChange = percChange
        
class User(BaseModel):
    table_name = "User"

    def __init__(self, id=None, name=None, cTraderId=None, googleId=None, email=None, deviceUID=None):
        self.id = id
        self.name = name
        self.cTraderId = cTraderId
        self.googleId = googleId
        self.email = email
        self.deviceUID = deviceUID
    
database = DATABASE()