from database import DATABASE
from log import log
from counter import counter
from platform_connector import platform_api
from database import Entry, Close, Position, User, Plan
from datetime import datetime


def get_list_from_string(string):
    return [int(x) for x in string.strip('[]').split(', ')]

class TRADE_EXECUTOR:
    def __init__(self):
        pass
        
    def enter_trade(self, new_trade_obj, cTraderId):
        symbol_name = new_trade_obj["SymbolName"]
        direction = new_trade_obj["Direction"]
        
        # get the current values from the platform in time of executing the trade
        symbol_obj = platform_api.get_symbol_info(symbol_name)

        if not symbol_obj:
            log.print("symbol not found")
            return 0
        new_trade_obj['ContractSize'] = symbol_obj["trade_contract_size"]
        
        # get current prices
        ask, bid = platform_api.get_symbol_prices(symbol_name)
        new_trade_obj['EntryPrice'] = ask if direction == 1 else bid
        if new_trade_obj['EntryPrice'] == 0:
            log.print("price is 0")
            return 0
        
        # fill additional info
        entry_price = new_trade_obj['EntryPrice']
        free_margin = new_trade_obj['FreeMargin']
        
        if not counter.update_convertion_ratio(symbol_name, entry_price): # update the current convertion ratio
            log.print("convertion ratio not found")
            log.print(new_trade_obj)
            return 0
        
        # save the position to DB
        user = User.get(cTraderId=cTraderId)
        user_id = user.id
        cPositionId = new_trade_obj['TradeId']
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        for model_name in counter.model_dict.keys():
            model = counter.model_dict[model_name]
            volume = model.count_volume(new_trade_obj, entry_price, counter.max_loss_per_trade, free_margin)
            margin = counter.count_margin(new_trade_obj, volume)
            plan_id = Plan.get(name=model_name).id
            position = Position.create(cPositionId=cPositionId, timestamp=timestamp, symbolName=new_trade_obj['SymbolName'], UserId=user_id, PlanId=plan_id, direction=new_trade_obj['Direction'], volume=volume, margin=margin, percChange=None)
            
            entry = Entry.create(entryPrice=new_trade_obj['EntryPrice'], stopLoss=new_trade_obj['StopLoss'], takeProfit=new_trade_obj['TakeProfit'], balance=new_trade_obj['BalanceOnEntry'], PositionId=position.id)

        return 1
            
    def close_position(self, cPositionId, ask, bid, stop_loss, take_profit):
        # check if the trade is managed by ALTRADIA
        position_list = Position.get(cPositionId=cPositionId)
        if not position_list:
            log.print("position is not managed by ALTRADIA: "+str(cPositionId))
            return 0    
        
        for position in position_list:
            # get the adequate entry object
            entry = Entry.get(PositionId=position.id)

            if not entry:
                log.print("entry not found")
                log.print(entry)
                continue
            
            # count the values
            direction = position.direction
            margin = position.margin
            volume = position.volume
            entry_price = entry.entryPrice
            close_price = bid if direction == 1 else ask
            balance_on_entry = entry.balance
            perc_change = None
            
            if direction == 1: # for up trades
                perc_change = ((close_price - entry_price) / entry_price) * counter.leverage
            elif direction == -1: # for down
                perc_change = ((entry_price - close_price) / entry_price) * counter.leverage
                
            total_PL = perc_change * margin - volume * counter.fee_per_lot
            perc_change = (balance_on_entry + total_PL) / balance_on_entry
            
            balance_on_close = perc_change * balance_on_entry
            
            # make and save the close object and all save
            close = Close.create(closePrice=close_price, stopLoss=stop_loss, takeProfit=take_profit, balance=balance_on_close, PositionId=position.id)

            position.percChange = perc_change
            position.save()
        
        
        return 1
        
trade_executor = TRADE_EXECUTOR()