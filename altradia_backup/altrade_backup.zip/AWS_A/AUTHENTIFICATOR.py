from database import User
from google.auth.transport import requests as google_requests
from google.oauth2 import id_token
from log import log

CLIENT_ID = "113341013590-g96htkvg8oaklftlr36pebc51mmb3mrh.apps.googleusercontent.com"

class AUTHENTIFICATOR:
    def __init__(self):
        pass
    
    # def register_user(self, cTraderId, deviceUID):
    #     new_user = User.create(cTraderId=cTraderId, deviceUID=deviceUID)
        
    def is_registered(self, cTraderId, deviceUID):
        if cTraderId is None:
            return "cTraderId not registered"
        
        user = User.get(cTraderId=cTraderId)
        if user: # if is registered to database
            user_deviceUID = user.deviceUID # if the deviceUID is registered 
            if user_deviceUID == deviceUID:
                return 1
            else:
                return "deviceUID incorrect" 
        
        return "user not found"
    
    def register_device(self, deviceUID, googleId, cTraderId):
        '''
            register the device; if the client has changed cTraderId on his googleId, then change the cTraderId
        '''
        
        user = User.get(googleId=googleId)
        
        if not user:
            return "user not registered in ALTRADIA"
        
        if user.cTraderId != cTraderId:          # for the first registration
            user.cTraderId = cTraderId
            
        user.deviceUID = deviceUID

        user.save()
        return 1
    
    def register_user(self, verified_user_dict):
        googleId = verified_user_dict['googleId']
        email = verified_user_dict['email']
        name = verified_user_dict['name']
        
        user_potential = User.get(googleId=googleId)
        if user_potential:
            return {'Result': "Already registered"}
        
        user = User.create(googleId=googleId, email=email, name=name)
        
        return 1
    
    def verify_googleToken(self, token):
        try:
            # Specify the CLIENT_ID of the app that accesses the backend:
            id_info = id_token.verify_oauth2_token(token, google_requests.Request(), CLIENT_ID)

            # If the token is valid, `id_info` will contain the user's information.
            if id_info['iss'] not in ['accounts.google.com', 'https://accounts.google.com']:
                raise ValueError('Wrong issuer.')

            # The token is valid; you can extract user details.
            googleId = id_info['sub']  # User's Google ID
            user_email = id_info['email']
            user_name = id_info['name']

            # Return or use the verified user info
            return {
                'googleId': googleId,
                'email': user_email,
                'name': user_name,
            }

        except ValueError:
            # Invalid token
            return None
        
    def deschiffre_cTraderId(self, deviceUID):
        key_dict = {}
        i = 0
        while len(key_dict) < 10:
            k = deviceUID[i*2]

            if k in key_dict.keys():
                i += 1
                continue
            
            key_dict[k] = str(len(key_dict))
            i += 1
            
        deschiffered_char_list = [key_dict[str(deviceUID[i*2+1])] for i in range(63) if str(deviceUID[i*2+1]) in key_dict.keys()]
        length = int("".join(deschiffered_char_list[:2]))
        cTraderId = int("".join(deschiffered_char_list[2:length+2]))
        
        return cTraderId
    
auth = AUTHENTIFICATOR()