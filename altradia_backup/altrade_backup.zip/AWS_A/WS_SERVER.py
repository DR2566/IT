from log import log
import asyncio
import websockets
import ssl  # Import the SSL module
import json
from AUTHENTIFICATOR import auth



# Add paths to your SSL certificate and private key
SSL_CERTIFICATE = '/etc/letsencrypt/live/algapia.zapto.org/cert.pem'
SSL_KEY = '/etc/letsencrypt/live/algapia.zapto.org/privkey.pem'

class WS_SERVER:
    class CLIENT:
        def __init__(self, cTraderId, deviceUID, websocket):
            self.cTraderId = cTraderId
            self.deviceUID = deviceUID
            self.connection = websocket.remote_address
            self.websocket = websocket
            
        def __repr__(self):
            return str({ att:vars(self)[att] for att in vars(self).keys() if att != 'websocket'})
            
            
    def __init__(self):
        self.connected_clients_list = []
        
    def connect_client(self, request, websocket):
        deviceUID = request["deviceUID"]
        # check if the client is registered
        cTraderId = auth.deschiffre_cTraderId(deviceUID)
        
        new_client = self.CLIENT(cTraderId, deviceUID, websocket)
        self.disconnect_client(client=new_client) # try to remove previous connection
        
        if auth.is_registered(cTraderId, deviceUID): 
            self.connected_clients_list.append(new_client)
            log.server_format_log("WS SERVER", "connect_client", "new client connection: "+str(new_client.cTraderId), enter=False)
            log.print("connected clients: ")
            log.print([c for c in self.connected_clients_list])
            log.print("\n")
            return {"result": "connected"}, 1
        else:
            log.server_format_log("WS SERVER", "connect_client", "client not authorized: "+str(new_client.cTraderId))
            return {"result": "User not known :/"}, 0
    
    def ping(self):
        return {"result": "ping"}, 1
        
    async def send(self, response, websocket):
        await websocket.send(json.dumps(response))
        
    def get_client(self, deviceUID):
        client_list = [client for client in self.connected_clients_list if client.deviceUID == deviceUID] # depending on its deviceUID
        if len(client_list) != 0:
            return client_list[0]
        else:
            return None
    
    def disconnect_client(self, connection=False, client=False):
        if client:
            self.connected_clients_list[:] = [c for c in self.connected_clients_list if c.deviceUID != client.deviceUID] # remove the adequate client depending on its deviceUID
            log.server_format_log("WS SERVER", "client_disconnected", "client: "+str(client.cTraderId))
        elif connection:
            self.connected_clients_list[:] = [c for c in self.connected_clients_list if c.connection != connection] # remove the adequate client depending on its deviceUID
            log.server_format_log("WS SERVER", "client_disconnected", "client: "+str(connection[0]))
    
    async def process_request(self, request, websocket):
        action = str(request['action'])
        
        # action switch
        if action == "connect":
            response, status = self.connect_client(request, websocket)
            
        elif action == "ping":
            response, status = self.ping()
            
        else:
            response, status = {"result":"action not known"}, 0
            
        response["type"] = "response"
        # response variants
        if status == 1:
            await self.send(response, websocket)
            
        elif status == 0:
            await self.send(response, websocket)
            await websocket.close()
            
    async def send_new_trade(self, deviceUID, position_obj):
            # prepare the request for giving know the AWS about the new trade
        request = {
            "type" : "request",
            "action": "new_trade",
            "positionObj": position_obj
        }
        
        # ---  the WS part
        # choose the right client that placed the trade depending on the IP address
        client = self.get_client(deviceUID)
        if not client:
            return {'result': "ws client not found"}

        # send the newTradeObj
        await client.websocket.send(json.dumps(request))
        return {'result': "1"}
    
ws_server = WS_SERVER()
    
async def websocket_handler(websocket, path):
    
    try:
        async for message in websocket:
            
            request = json.loads(message)
            
            await ws_server.process_request(request, websocket)
            
    except websockets.ConnectionClosed:
        ws_server.disconnect_client(connection=websocket.remote_address)
        

async def start_websocket_server():
    ssl_context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
    ssl_context.load_cert_chain(certfile=SSL_CERTIFICATE, keyfile=SSL_KEY)

    server = await websockets.serve(websocket_handler, "0.0.0.0", 7777, ssl=ssl_context)
    log.print("WebSocket server started with SSL (WSS)")
    await server.wait_closed()

